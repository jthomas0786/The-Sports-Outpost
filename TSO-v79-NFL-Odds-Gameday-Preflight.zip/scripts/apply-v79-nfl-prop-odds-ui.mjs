#!/usr/bin/env node
/** One-time safe source patch for v79. Refuses to write if expected v72/v78 text is not present. */
import fs from 'node:fs/promises';

async function patch(file,replacements){
  let s=await fs.readFile(file,'utf8');
  for(const [from,to] of replacements){
    if(s.includes(to)) continue;
    if(!s.includes(from)) throw new Error(`${file}: expected source text not found: ${from.slice(0,90)}`);
    s=s.replace(from,to);
  }
  await fs.writeFile(file,s);
  console.log(`patched ${file}`);
}

await patch('sports/nfl-research-ui.js',[
  ["firstTd:{button:'1ST TD',label:'First TD',market:'FIRST TD',unit:'TD',oddsKey:null}","firstTd:{button:'1ST TD',label:'First TD',market:'FIRST TD',unit:'TD',oddsKey:'firstTd'}"],
  ["passYds:{button:'PASS YDS',label:'Passing Yards',market:'PASSING YARDS',unit:'YDS',oddsKey:null}","passYds:{button:'PASS YDS',label:'Passing Yards',market:'PASSING YARDS',unit:'YDS',oddsKey:'passYds'}"],
  ["completions:{button:'COMP',label:'Completions',market:'COMPLETIONS',unit:'COMP',oddsKey:null}","completions:{button:'COMP',label:'Completions',market:'COMPLETIONS',unit:'COMP',oddsKey:'completions'}"],
  ["if(key==='atd') return slot.best?{line:.5,...slot.best,source:'Sportsbook'}:null;","if(key==='atd'||key==='firstTd') return slot.best?{line:.5,...slot.best,source:'Sportsbook',gameId:hit.game?.gameId||null,eventId:hit.game?.fixtureId||null}:null;"],
  ["return best&&Number.isFinite(Number(slot.line))?{line:Number(slot.line),...best,source:'Sportsbook'}:null;","return best&&Number.isFinite(Number(slot.line))?{line:Number(slot.line),...best,source:'Sportsbook',gameId:hit.game?.gameId||null,eventId:hit.game?.fixtureId||null}:null;"],
  ["grade:prob>=18?'A':prob>=13?'B+':prob>=8?'B':'C',seasonPg,recent,defense,offer,lineSource:'TSO model'","grade:prob>=18?'A':prob>=13?'B+':prob>=8?'B':'C',seasonPg,recent,defense,offer,lineSource:offer?'Sportsbook':'TSO model'"],
  ["const leg={id,kind:'prop',player:r.name,market:ctx.meta.market,line,pct:ctx.prob,grade:ctx.grade,game:`${team} vs ${opp||'DEF'}`,player_id:r.espnId||r.gsisId||r.pfrId||null,price:ctx.offer?.price??null,book:ctx.offer?.book??null,link:ctx.offer?.link??null,line_source:ctx.lineSource};","const leg={id,kind:'prop',sport:'nfl',prop_key:ctx.key,side:'over',player:r.name,market:ctx.meta.market,line,pct:ctx.prob,grade:ctx.grade,game:`${team} vs ${opp||'DEF'}`,game_pk:Number(ctx.offer?.gameId)||null,event_id:ctx.offer?.eventId||null,player_id:r.espnId||r.gsisId||r.pfrId||null,price:ctx.offer?.price??null,book:ctx.offer?.book??null,link:ctx.offer?.link??null,line_source:ctx.lineSource};"],
]);

await patch('sports/router.js',[["./nfl-research-ui.js?v=72","./nfl-research-ui.js?v=79"]]);
console.log('v79 NFL prop-odds UI patch complete.');
