#!/usr/bin/env node
import fs from 'node:fs';

function mustReplace(text, search, replacement, label){
  if(!text.includes(search)) throw new Error(`v81 patch could not find ${label}`);
  return text.replace(search,replacement);
}

// ---------------------------------------------------------------------------
// index.html — allow NFL ATD legs through the existing point wager panel and
// carry sport/market metadata to the server. MLB HR remains supported.
// ---------------------------------------------------------------------------
const indexPath='index.html';
let index=fs.readFileSync(indexPath,'utf8');

const oldEligibility=`  // v1 scope: only Home Run legs can be wagered — everything else in the
  // slip (other props, 1st-inning O/U) can still be shared or sent to
  // GamblyBot, just not wagered yet.
  const ineligible = betslip.filter(l => l.market !== 'HR' || l.player_id == null || l.game_pk == null || l.pct == null);
  if(ineligible.length){
    panel.style.display = 'block';
    panel.innerHTML = \`<div class="bs-wager-note">Only Home Run picks can be wagered right now —
      remove \${ineligible.length === betslip.length ? 'these' : \`\${ineligible.length} non-HR\`} leg(s) to continue.</div>\`;
    return;
  }`;
const newEligibility=`  // v81 scope: MLB Home Run + NFL Anytime TD are point-wager eligible.
  // Other markets can still live in the slip, but cannot be submitted yet.
  const wagerLegEligible = l => {
    const sport = String(l?.sport || (String(l?.market||'').toUpperCase()==='ATD' ? 'nfl' : 'mlb')).toLowerCase();
    const market = String(l?.market || '').trim().toUpperCase();
    const supported = (sport==='mlb' && market==='HR') || (sport==='nfl' && market==='ATD');
    return supported && l.player_id != null && l.game_pk != null && l.pct != null && l.slate_date;
  };
  const ineligible = betslip.filter(l => !wagerLegEligible(l));
  if(ineligible.length){
    panel.style.display = 'block';
    panel.innerHTML = \`<div class="bs-wager-note">Point wagers currently support MLB Home Run and NFL Anytime TD picks —
      remove \${ineligible.length === betslip.length ? 'these' : \`\${ineligible.length} unsupported\`} leg(s) to continue.</div>\`;
    return;
  }`;
index=mustReplace(index,oldEligibility,newEligibility,'HR-only wager eligibility block');

const oldLegMap=`    const legs = betslip.map(l => ({
      player_id: l.player_id, player_name: l.player,
      game_pk: l.game_pk, slate_date: l.slate_date,
      probability: l.pct / 100,   // stored as a whole-number percent on the leg; RPC expects 0-1
    }));`;
const newLegMap=`    const legs = betslip.map(l => {
      const market = String(l.market || '').trim().toUpperCase();
      const sport = String(l.sport || (market==='ATD' ? 'nfl' : 'mlb')).toLowerCase();
      return {
        sport, market, prop_key: l.prop_key || (market==='ATD' ? 'atd' : 'hr'),
        player_id: l.player_id, player_name: l.player,
        game_pk: l.game_pk, event_id: l.event_id || null, slate_date: l.slate_date,
        probability: l.pct / 100,   // stored as a whole-number percent on the leg; RPC expects 0-1
      };
    });`;
index=mustReplace(index,oldLegMap,newLegMap,'wager leg payload map');
fs.writeFileSync(indexPath,index);
console.log('✓ patched index.html for MLB HR + NFL ATD point wagers');

// ---------------------------------------------------------------------------
// NFL Player Modal enhancement — filter exchange/DFS rows (especially Novig),
// preserve the actual game date, and make its ATD slip leg wager-ready too.
// ---------------------------------------------------------------------------
const uiPath='sports/nfl-research-ui.js';
let ui=fs.readFileSync(uiPath,'utf8');

const oldOffer=`function propOddsOffer(r,key){
  const hit=findOddsPlayer(r); if(!hit) return null;
  const meta=NFL_PROP_META[key], slot=meta?.oddsKey ? hit.player?.odds?.[meta.oddsKey] : null;
  if(!slot) return null;
  if(key==='atd'||key==='firstTd') return slot.best?{line:.5,...slot.best,source:'Sportsbook',gameId:hit.game?.gameId||null,eventId:hit.game?.fixtureId||null}:null;
  const best=slot.over?.best;
  return best&&Number.isFinite(Number(slot.line))?{line:Number(slot.line),...best,source:'Sportsbook',gameId:hit.game?.gameId||null,eventId:hit.game?.fixtureId||null}:null;
}`;
const newOffer=`const NFL_SPORTSBOOKS=/^(bovada|caesars|draftkings|fanduel|fanatics|fliff|hard rock(?: bet)?|parx(?: casino)?|bet365|betmgm|espn bet|pinnacle|betrivers|pmu|unibet|sportsbet|rushbet)$/i;
function isNflSportsbookOffer(o){return !!o&&NFL_SPORTSBOOKS.test(String(o.book||'').trim());}
function bestNflSportsbook(list){return [...(list||[])].filter(isNflSportsbookOffer).filter(x=>Number.isFinite(Number(x.price))).sort((a,b)=>Number(b.price)-Number(a.price))[0]||null;}
function propOddsOffer(r,key){
  const hit=findOddsPlayer(r); if(!hit) return null;
  const meta=NFL_PROP_META[key], slot=meta?.oddsKey ? hit.player?.odds?.[meta.oddsKey] : null;
  if(!slot) return null;
  const common={source:'Sportsbook',gameId:hit.game?.gameId||null,eventId:hit.game?.fixtureId||null,startDateUTC:hit.game?.startDateUTC||null};
  if(key==='atd'||key==='firstTd'){
    const best=bestNflSportsbook(slot.all)||(isNflSportsbookOffer(slot.best)?slot.best:null);
    return best?{line:.5,...best,...common}:null;
  }
  const best=bestNflSportsbook(slot.over?.all)||(isNflSportsbookOffer(slot.over?.best)?slot.over.best:null);
  return best&&Number.isFinite(Number(slot.line))?{line:Number(slot.line),...best,...common}:null;
}`;
ui=mustReplace(ui,oldOffer,newOffer,'NFL modal sportsbook offer function');

const oldSlipStart=`function slipHasLeg(id){
  try{return (JSON.parse(localStorage.getItem('dw_betslip')||'[]')||[]).some(l=>l?.id===id);}catch{return false;}
}
function propSlipHTML(r,ctx,team,opp,edge){`;
const newSlipStart=`function slipHasLeg(id){
  try{return (JSON.parse(localStorage.getItem('dw_betslip')||'[]')||[]).some(l=>l?.id===id);}catch{return false;}
}
function nflPointSlateDate(utc){
  if(!utc) return null;
  const d=new Date(utc); if(!Number.isFinite(d.getTime())) return null;
  try{const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(d).filter(x=>x.type!=='literal').map(x=>[x.type,x.value]));return \`${'${p.year}'}-${'${p.month}'}-${'${p.day}'}\`;}catch{return d.toISOString().slice(0,10);}
}
function propSlipHTML(r,ctx,team,opp,edge){`;
ui=mustReplace(ui,oldSlipStart,newSlipStart,'NFL modal slip helper');

const oldLeg=`  const id=\`${'${r.name}'}|${'${ctx.meta.market}'}|${'${fmtLine(line)}'}\`;
  const leg={id,kind:'prop',sport:'nfl',prop_key:ctx.key,side:'over',player:r.name,market:ctx.meta.market,line,pct:ctx.prob,grade:ctx.grade,game:\`${'${team}'} vs ${'${opp||\'DEF\'}'}\`,game_pk:Number(ctx.offer?.gameId)||null,event_id:ctx.offer?.eventId||null,player_id:r.espnId||r.gsisId||r.pfrId||null,price:ctx.offer?.price??null,book:ctx.offer?.book??null,link:ctx.offer?.link??null,line_source:ctx.lineSource};`;
const newLeg=`  const wagerMarket=ctx.key==='atd'?'ATD':ctx.meta.market;
  const id=\`${'${r.name}'}|${'${wagerMarket}'}|${'${fmtLine(line)}'}\`;
  const leg={id,kind:'prop',sport:'nfl',prop_key:ctx.key,side:'over',player:r.name,market:wagerMarket,line,pct:ctx.prob,grade:ctx.grade,game:\`${'${team}'} vs ${'${opp||\'DEF\'}'}\`,game_pk:Number(ctx.offer?.gameId||r.gameId)||null,event_id:ctx.offer?.eventId||null,player_id:r.espnId||r.gsisId||r.pfrId||null,price:ctx.offer?.price??null,book:ctx.offer?.book??null,link:ctx.offer?.link??null,line_source:ctx.lineSource,slate_date:nflPointSlateDate(ctx.offer?.startDateUTC||findOddsPlayer(r)?.game?.startDateUTC)};`;
ui=mustReplace(ui,oldLeg,newLeg,'NFL modal wager leg');

fs.writeFileSync(uiPath,ui);
console.log('✓ patched sports/nfl-research-ui.js for sportsbook-only odds + ATD point wager metadata');
